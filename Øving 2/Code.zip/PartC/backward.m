function b_tp1 = backward(O,T,b)
b_tp1 = T*O*b;


