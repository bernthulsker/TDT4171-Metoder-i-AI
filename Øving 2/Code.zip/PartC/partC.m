ev = [1 1 0 1 1];
prior = [0.9 0.2];


[sv,f,b] = forBackWard(ev,prior);
